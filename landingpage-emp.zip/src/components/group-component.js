import styles from "./group-component.module.css";

const GroupComponent = () => {
  return (
    <div className={styles.rectangleParent}>
      <div className={styles.instanceChild} />
      <img
        className={styles.vectorIcon}
        loading="lazy"
        alt=""
        src="/vector-12.svg"
      />
      <b className={styles.letsHelpYou}>lets help you figure out what ?</b>
    </div>
  );
};

export default GroupComponent;
