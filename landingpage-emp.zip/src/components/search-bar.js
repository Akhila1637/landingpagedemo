import { Button } from "@mui/material";
import StatusItem from "./status-item";
import styles from "./search-bar.module.css";

const SearchBar = () => {
  return (
    <div className={styles.searchBar}>
      <div className={styles.searchContainer}>
        <div className={styles.searchInput}>
          <div className={styles.searchField}>
            <div className={styles.search}>
              <div className={styles.searchLabel}>
                <div className={styles.statusLabel}>
                  <b className={styles.trackCandidateStatus}>
                    Track candidate status
                  </b>
                </div>
                <div className={styles.header}>
                  <div className={styles.header1}>
                    <div className={styles.headerChild} />
                    <div className={styles.divider} />
                    <div className={styles.brandNavigation}>
                      <div className={styles.logoParent}>
                        <img
                          className={styles.logoIcon}
                          alt=""
                          src="/vector-2-2.svg"
                        />
                        <img
                          className={styles.logoIcon1}
                          alt=""
                          src="/vector-2-2.svg"
                        />
                      </div>
                      <div className={styles.logoGroup}>
                        <img
                          className={styles.logoIcon2}
                          alt=""
                          src="/vector-1-2.svg"
                        />
                        <div className={styles.vectorParent}>
                          <img
                            className={styles.frameChild}
                            alt=""
                            src="/vector-1-2.svg"
                          />
                          <i className={styles.employia}>Employia</i>
                          <img
                            className={styles.vectorIcon}
                            alt=""
                            src="/vector-1.svg"
                          />
                        </div>
                      </div>
                    </div>
                    <img
                      className={styles.headerItem}
                      alt=""
                      src="/ellipse-93@2x.png"
                    />
                    <div className={styles.profile}>
                      <div className={styles.profileIcon} />
                    </div>
                  </div>
                  <div className={styles.notification}>
                    <img
                      className={styles.notificationIcon}
                      alt=""
                      src="/vector-2.svg"
                    />
                  </div>
                </div>
                <div className={styles.menu}>
                  <div className={styles.menuChild} />
                  <div className={styles.menuInner}>
                    <Button
                      className={styles.instanceChild}
                      disableElevation={true}
                      variant="contained"
                      sx={{
                        textTransform: "none",
                        color: "#000",
                        fontSize: "13.8",
                        background: "#fff",
                        borderRadius: "0px 0px 0px 0px",
                        "&:hover": { background: "#fff" },
                      }}
                    >
                      Support
                    </Button>
                  </div>
                </div>
              </div>
              <div className={styles.menuNavigation}>
                <div className={styles.menuContainer}>
                  <div className={styles.menuContainerInner}>
                    <div className={styles.frameParent}>
                      <div className={styles.rectangleParent}>
                        <div className={styles.frameItem} />
                        <div className={styles.candidateTraking}>
                          Candidate Traking
                        </div>
                        <div className={styles.trackingIcon}>
                          <img
                            className={styles.solargraphBrokenIcon}
                            alt=""
                            src="/solargraphbroken.svg"
                          />
                        </div>
                      </div>
                      <div className={styles.historyMenu}>
                        <div className={styles.rectangleGroup}>
                          <div className={styles.frameInner} />
                          <div className={styles.history}>History</div>
                          <div className={styles.historyIcon}>
                            <img
                              className={styles.vectorIcon1}
                              alt=""
                              src="/vector-3.svg"
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className={styles.statusSearch}>
                    <div className={styles.searchContainer1}>
                      <div className={styles.searchInput1}>
                        <div className={styles.rectangleContainer}>
                          <div className={styles.instanceItem} />
                          <img
                            className={styles.icbaselineSearchIcon}
                            alt=""
                            src="/icbaselinesearch.svg"
                          />
                          <div className={styles.inputLabel}>
                            <div className={styles.enterYourEmail}>
                              Enter your Email or Mobile Number
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className={styles.checkStatusButton}>
                        <div className={styles.checkStatusButtonInner}>
                          <div className={styles.groupDiv}>
                            <div className={styles.rectangleDiv} />
                            <div className={styles.buttonLabel}>
                              <b className={styles.checkStatus}>Check status</b>
                              <div className={styles.buttonLabelChild} />
                              <b className={styles.checkStatus1}>
                                Check status
                              </b>
                            </div>
                          </div>
                        </div>
                        <div className={styles.candidateStatus}>
                          <div className={styles.candidateStatusChild} />
                          <div className={styles.statusList}>
                            <StatusItem iNFOSYS="INFOSYS" />
                            <div className={styles.statusItem}>
                              <div className={styles.statusItemChild} />
                              <div className={styles.frameGroup}>
                                <div className={styles.statusIconsParent}>
                                  <textarea
                                    className={styles.statusIcons}
                                    rows={9}
                                    cols={18}
                                  />
                                  <div className={styles.ellipseDiv} />
                                  <div className={styles.frameChild1} />
                                  <div className={styles.screeningRoundWrapper}>
                                    <div className={styles.screeningRound}>
                                      Screening Round
                                    </div>
                                  </div>
                                  <div className={styles.microsoft}>
                                    Microsoft
                                  </div>
                                </div>
                                <Button
                                  className={styles.instanceInner}
                                  disableElevation={true}
                                  variant="contained"
                                  sx={{
                                    textTransform: "none",
                                    color: "#fff",
                                    fontSize: "12.3",
                                    background: "#000",
                                    borderRadius: "0px 0px 0px 0px",
                                    "&:hover": { background: "#000" },
                                    height: 29.8,
                                  }}
                                >
                                  View more
                                </Button>
                              </div>
                            </div>
                          </div>
                          <div className={styles.statusList1}>
                            <div className={styles.frameDiv}>
                              <div className={styles.frameChild2} />
                              <div className={styles.frameContainer}>
                                <div className={styles.rectangleParent1}>
                                  <textarea
                                    className={styles.rectangleTextarea}
                                    rows={9}
                                    cols={18}
                                  />
                                  <div className={styles.frameChild3} />
                                  <div className={styles.frameChild4} />
                                  <div
                                    className={
                                      styles.waitingForFinalRoundResultWrapper
                                    }
                                  >
                                    <div className={styles.waitingForFinal}>
                                      Waiting for Final Round result
                                    </div>
                                  </div>
                                  <div className={styles.google}>Google</div>
                                </div>
                                <Button
                                  className={styles.groupButton}
                                  disableElevation={true}
                                  variant="contained"
                                  sx={{
                                    textTransform: "none",
                                    color: "#fff",
                                    fontSize: "12.3",
                                    background: "#000",
                                    borderRadius: "0px 0px 0px 0px",
                                    "&:hover": { background: "#000" },
                                    height: 29.8,
                                  }}
                                >
                                  View more
                                </Button>
                              </div>
                            </div>
                            <StatusItem
                              iNFOSYS="Adobe"
                              propBackgroundColor="#d9d9d9"
                              propBorder="unset"
                              propBackgroundColor1="#d9d9d9"
                              propBorder1="unset"
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className={styles.container}>
                  <div className={styles.rectangleParent2}>
                    <div className={styles.frameChild5} />
                    <div className={styles.frameChild6} />
                  </div>
                </div>
              </div>
              <div className={styles.container1}>
                <div className={styles.rectangleParent3}>
                  <div className={styles.frameChild7} />
                  <div className={styles.frameChild8} />
                </div>
              </div>
            </div>
          </div>
          <div className={styles.container2}>
            <div className={styles.getOperator}>
              <div className={styles.empoweringSeamlessRecruitmen}>
                Empowering seamless recruitment experiences for our valued
                customers.
              </div>
              <div className={styles.ourCustomersheader}>
                <h1 className={styles.ourCustomers}>Our Customers</h1>
                <div className={styles.foldOperatorWrapper}>
                  <div className={styles.foldOperator}>
                    <img
                      className={styles.foldOperatorChild}
                      alt=""
                      src="/line-1.svg"
                    />
                  </div>
                </div>
              </div>
              <div className={styles.ourCustomersSlider}>
                <div className={styles.findIndexOperatorParent}>
                  <Button
                    className={styles.findIndexOperator}
                    disableElevation={true}
                    variant="text"
                    sx={{
                      borderRadius: "0px 0px 0px 0px",
                      width: 403.4,
                      height: 113.3,
                    }}
                  />
                  <div className={styles.sliderItems}>
                    <img
                      className={styles.sliderItemsChild}
                      alt=""
                      src="/rectangle-27@2x.png"
                    />
                  </div>
                  <button className={styles.findIndexOperator1}>
                    <img
                      className={styles.findIndexOperatorChild}
                      alt=""
                      src="/rectangle-29@2x.png"
                    />
                  </button>
                  <img
                    className={styles.findIndexOperator2}
                    alt=""
                    src="/find-index-operator@2x.png"
                  />
                  <div className={styles.sliderItems1}>
                    <img
                      className={styles.sliderItemsItem}
                      loading="lazy"
                      alt=""
                      src="/rectangle-31@2x.png"
                    />
                  </div>
                  <div className={styles.sliderItems2}>
                    <img
                      className={styles.sliderItemsInner}
                      alt=""
                      src="/rectangle-32@2x.png"
                    />
                  </div>
                  <div className={styles.sliderItems3}>
                    <img
                      className={styles.rectangleIcon}
                      alt=""
                      src="/rectangle-33@2x.png"
                    />
                  </div>
                  <div className={styles.sliderItems4}>
                    <img
                      className={styles.sliderItemsChild1}
                      loading="lazy"
                      alt=""
                      src="/rectangle-34@2x.png"
                    />
                  </div>
                  <div className={styles.sliderControl}>
                    <img
                      className={styles.outputGeneratorIcon}
                      loading="lazy"
                      alt=""
                      src="/rectangle-35@2x.png"
                    />
                  </div>
                  <div className={styles.sliderItems5}>
                    <img
                      className={styles.sliderItemsChild2}
                      loading="lazy"
                      alt=""
                      src="/rectangle-40@2x.png"
                    />
                  </div>
                  <div className={styles.sliderItems6}>
                    <img
                      className={styles.sliderItemsChild3}
                      alt=""
                      src="/rectangle-27@2x.png"
                    />
                  </div>
                  <div className={styles.sliderItems7}>
                    <img
                      className={styles.sliderItemsChild4}
                      alt=""
                      src="/rectangle-29@2x.png"
                    />
                  </div>
                  <img
                    className={styles.findIndexOperator3}
                    alt=""
                    src="/find-index-operator@2x.png"
                  />
                  <div className={styles.sliderItems8}>
                    <img
                      className={styles.sliderItemsChild5}
                      loading="lazy"
                      alt=""
                      src="/rectangle-31@2x.png"
                    />
                  </div>
                  <div className={styles.sliderItems9}>
                    <img
                      className={styles.sliderItemsChild6}
                      alt=""
                      src="/rectangle-32@2x.png"
                    />
                  </div>
                  <div className={styles.sliderItems10}>
                    <img
                      className={styles.sliderItemsChild7}
                      alt=""
                      src="/rectangle-33@2x.png"
                    />
                  </div>
                  <div className={styles.sliderItems11}>
                    <img
                      className={styles.sliderItemsChild8}
                      loading="lazy"
                      alt=""
                      src="/rectangle-34@2x.png"
                    />
                  </div>
                  <img
                    className={styles.treeStructureIcon}
                    loading="lazy"
                    alt=""
                    src="/rectangle-35@2x.png"
                  />
                </div>
              </div>
              <div className={styles.getOperatorInner}>
                <div className={styles.frame11variant2Wrapper}>
                  <div className={styles.frame11variant2}>
                    <div className={styles.title}>
                      <b className={styles.byUsecase}>By UseCase</b>
                      <div className={styles.selection}>
                        <div className={styles.useCase}>
                          <div className={styles.subtree}>
                            <div className={styles.useCase1Parent}>
                              <b className={styles.useCase1}>Use Case 1</b>
                              <img
                                className={styles.lineIcon}
                                alt=""
                                src="/line-2.svg"
                              />
                            </div>
                          </div>
                        </div>
                        <div className={styles.useCaseList}>
                          <div className={styles.topologicalSortWrapper}>
                            <div className={styles.topologicalSort}>
                              <div className={styles.cyclicGraph}>
                                <b className={styles.useCase11}>Use Case 1</b>
                                <img
                                  className={styles.cyclicGraphChild}
                                  loading="lazy"
                                  alt=""
                                  src="/line-2.svg"
                                />
                              </div>
                            </div>
                          </div>
                          <div className={styles.breadthFirstSearchWrapper}>
                            <div className={styles.breadthFirstSearch}>
                              <div className={styles.graphTraversal}>
                                <b className={styles.useCase12}>Use Case 1</b>
                                <img
                                  className={styles.graphTraversalChild}
                                  loading="lazy"
                                  alt=""
                                  src="/line-2.svg"
                                />
                              </div>
                            </div>
                          </div>
                          <div className={styles.useCaseListInner}>
                            <div className={styles.frameWrapper}>
                              <div className={styles.useCase1Group}>
                                <b className={styles.useCase13}>Use Case 1</b>
                                <img
                                  className={styles.frameChild9}
                                  loading="lazy"
                                  alt=""
                                  src="/line-2.svg"
                                />
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className={styles.description}>
                      <div className={styles.graphAlgorithms}>
                        <div className={styles.loremIpsumDolorSitAmetCoParent}>
                          <b className={styles.loremIpsumDolor}>
                            Lorem ipsum dolor sit amet, consectetur adipiscing
                            elit. Nullam quis justo ac justo mattis volutpat non
                            sit amet dolor. Sed gravida, sapien sit amet
                            tristique tempor, ante dolor suscipit nisi, non
                            pulvinar felis felis vel mi. Proin vitae sapien id
                            justo faucibus placerat. Pellentesque habitant morbi
                            tristique senectus et netus et malesuada fames ac
                            turpis egestas. Integer sed vestibulum ipsum.
                            Vestibulum ante ipsum primis in faucibus orci luctus
                            et ultrices posuere cubilia curae; Sed ac nisi
                            ultricies, cursus odio non, sagittis urna. Integer
                            consequat ipsum vitae justo laoreet, nec molestie
                            nisl molestie.
                          </b>
                          <b className={styles.loremIpsumDolor1}>
                            Lorem ipsum dolor sit amet, consectetur adipiscing
                            elit. Nullam quis justo ac justo mattis volutpat non
                            sit amet dolor. Sed gravida, sapien sit amet
                            tristique tempor, ante dolor suscipit nisi, non
                            pulvinar felis felis vel mi. Proin vitae sapien id
                            justo faucibus placerat. Pellentesque habitant morbi
                            tristique senectus et netus et malesuada fames ac
                            turpis egestas. Integer sed vestibulum ipsum.
                            Vestibulum ante ipsum primis in faucibus orci luctus
                            et ultrices posuere cubilia curae; Sed ac nisi
                            ultricies, cursus odio non, sagittis urna. Integer
                            consequat ipsum vitae justo laoreet, nec molestie
                            nisl molestie.
                          </b>
                          <b className={styles.loremIpsumDolor2}>
                            Lorem ipsum dolor sit amet, consectetur adipiscing
                            elit. Nullam quis justo ac justo mattis volutpat non
                            sit amet dolor. Sed gravida, sapien sit amet
                            tristique tempor, ante dolor suscipit nisi, non
                            pulvinar felis felis vel mi. Proin vitae sapien id
                            justo faucibus placerat. Pellentesque habitant morbi
                            tristique senectus et netus et malesuada fames ac
                            turpis egestas. Integer sed vestibulum ipsum.
                            Vestibulum ante ipsum primis in faucibus orci luctus
                            et ultrices posuere cubilia curae; Sed ac nisi
                            ultricies, cursus odio non, sagittis urna. Integer
                            consequat ipsum vitae justo laoreet, nec molestie
                            nisl molestie.
                          </b>
                          <b className={styles.loremIpsumDolor3}>
                            Lorem ipsum dolor sit amet, consectetur adipiscing
                            elit. Nullam quis justo ac justo mattis volutpat non
                            sit amet dolor. Sed gravida, sapien sit amet
                            tristique tempor, ante dolor suscipit nisi, non
                            pulvinar felis felis vel mi. Proin vitae sapien id
                            justo faucibus placerat. Pellentesque habitant morbi
                            tristique senectus et netus et malesuada fames ac
                            turpis egestas. Integer sed vestibulum ipsum.
                            Vestibulum ante ipsum primis in faucibus orci luctus
                            et ultrices posuere cubilia curae; Sed ac nisi
                            ultricies, cursus odio non, sagittis urna. Integer
                            consequat ipsum vitae justo laoreet, nec molestie
                            nisl molestie.
                          </b>
                        </div>
                      </div>
                    </div>
                    <div className={styles.button}>
                      <div className={styles.buttonContent}>
                        <div className={styles.floydWarshallAlgorithm} />
                        <img
                          className={styles.primAlgorithmIcon}
                          loading="lazy"
                          alt=""
                          src="/rectangle-18@2x.png"
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className={styles.kruskalAlgorithm}>
              <div className={styles.kruskalAlgorithmChild} />
              <div className={styles.content}>
                <div className={styles.readyToDiveInWrapper}>
                  <h1 className={styles.readyToDive}>Ready to dive in?</h1>
                </div>
                <div className={styles.weReachedHere}>
                  We reached here with our hard work and dedication
                </div>
              </div>
              <div className={styles.buttonContainer}>
                <div className={styles.buttonContent1}>
                  <Button
                    className={styles.component1}
                    disableElevation={true}
                    variant="contained"
                    sx={{
                      textTransform: "none",
                      color: "#000",
                      fontSize: "30",
                      background: "#d9d9d9",
                      borderRadius: "0px 0px 0px 0px",
                      "&:hover": { background: "#d9d9d9" },
                      height: 84,
                    }}
                  >
                    Get Started
                  </Button>
                  <div className={styles.caption}>
                    <b className={styles.noCreditCard}>
                      No credit card required ✌️
                    </b>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <img className={styles.bot1} alt="" src="/bot-1.svg" />
    </div>
  );
};

export default SearchBar;
