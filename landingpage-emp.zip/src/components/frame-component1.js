import { Button } from "@mui/material";
import styles from "./frame-component1.module.css";

const FrameComponent1 = () => {
  return (
    <div className={styles.rectangleParent}>
      <div className={styles.frameChild} />
      <div className={styles.titleContainer}>
        <div className={styles.partnershipTitle}>
          <h1 className={styles.growWithUs}>Grow with us as a partner</h1>
        </div>
        <div className={styles.weReachedHere}>
          We reached here with our hard work and dedication
        </div>
      </div>
      <div className={styles.callToAction}>
        <Button
          className={styles.component2}
          disableElevation={true}
          variant="contained"
          sx={{
            textTransform: "none",
            color: "#fff",
            fontSize: "30",
            background: "#000",
            borderRadius: "0px 0px 0px 0px",
            "&:hover": { background: "#000" },
            width: 415,
            height: 84,
          }}
        >
          Get Started
        </Button>
      </div>
    </div>
  );
};

export default FrameComponent1;
