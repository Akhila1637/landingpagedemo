import GroupComponent from "./group-component";
import styles from "./frame-component.module.css";

const FrameComponent = () => {
  return (
    <div className={styles.faqContentWrapper}>
      <div className={styles.faqContent}>
        <div className={styles.rectangleParent}>
          <div className={styles.frameChild} />
          <img
            className={styles.frameItem}
            loading="lazy"
            alt=""
            src="/rectangle-53@2x.png"
          />
        </div>
        <div className={styles.rectangleGroup}>
          <div className={styles.frameInner} />
          <div className={styles.questionContainer}>
            <h1 className={styles.yourQuestionsOurContainer}>
              <p className={styles.yourQuestions}>Your questions?</p>
              <p className={styles.ourSolutions}>our solutions!</p>
            </h1>
          </div>
          <div className={styles.rectangleDiv} />
          <div className={styles.questionItemsParent}>
            <div className={styles.questionItems}>
              <div className={styles.instanceParent}>
                <GroupComponent />
                <GroupComponent />
                <GroupComponent />
                <GroupComponent />
                <GroupComponent />
              </div>
              <div className={styles.answerSpace}>
                <div className={styles.wrapperRectangle81}>
                  <img
                    className={styles.wrapperRectangle81Child}
                    loading="lazy"
                    alt=""
                    src="/rectangle-81@2x.png"
                  />
                </div>
              </div>
            </div>
            <div className={styles.userQuestions}>
              <div className={styles.userQuestionDetailsParent}>
                <div className={styles.userQuestionDetails}>
                  <div className={styles.haventSeenYousAskOne}>
                    <div className={styles.haventSeenYousContainer}>
                      <span>{`Havent seen yous? `}</span>
                      <span className={styles.askOne}>ask one</span>
                    </div>
                  </div>
                </div>
                <div className={styles.logoFooter}>
                  <div className={styles.logo}>
                    <img
                      className={styles.dataAggregatorIcon}
                      loading="lazy"
                      alt=""
                      src="/edge-subtree.svg"
                    />
                  </div>
                  <i className={styles.employia}>Employia</i>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FrameComponent;
