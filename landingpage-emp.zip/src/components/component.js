import ContentItems from "./content-items";
import styles from "./component.module.css";

const Component = () => {
  return (
    <section className={styles.component4}>
      <div className={styles.contentItemsParent}>
        <div className={styles.contentItems}>
          <div className={styles.contentDetails}>
            <div className={styles.circleOrganizerParent}>
              <div className={styles.circleOrganizer} />
              <img
                className={styles.frameChild}
                alt=""
                src="/rectangle-56@2x.png"
              />
              <img
                className={styles.frameItem}
                loading="lazy"
                alt=""
                src="/rectangle-56@2x.png"
              />
              <div className={styles.authorDetails}>
                <div className={styles.authorNameParent}>
                  <div className={styles.authorName}>
                    <div className={styles.nameContainer}>
                      <div className={styles.nameType}>
                        <div className={styles.amirUddin}>Amir Uddin</div>
                        <div
                          className={styles.uxDesigner}
                        >{`UX Designer `}</div>
                      </div>
                      <img
                        className={styles.nameContainerChild}
                        alt=""
                        src="/line-3.svg"
                      />
                    </div>
                  </div>
                  <div
                    className={styles.weWillAlso}
                  >{`We will also facilitate the business marketing of these products with our SEO experts so that they become a ready to use website & help sell product from company. We will also facilitate the business marketing of these products with our SEO experts so  facilitate the business marketing of these products `}</div>
                </div>
              </div>
            </div>
            <div className={styles.companyBranding}>
              <div className={styles.vectorParent}>
                <img
                  className={styles.vectorIcon}
                  loading="lazy"
                  alt=""
                  src="/vector-4.svg"
                />
                <i className={styles.employia}>Employia</i>
              </div>
            </div>
          </div>
        </div>
        <div className={styles.contentItems1}>
          <div className={styles.rectangleParent}>
            <div className={styles.frameInner} />
            <img
              className={styles.rectangleIcon}
              alt=""
              src="/rectangle-56@2x.png"
            />
            <img
              className={styles.frameChild1}
              loading="lazy"
              alt=""
              src="/rectangle-57-1@2x.png"
            />
            <div className={styles.duplicate}>
              <div className={styles.duplicate1}>
                <div className={styles.duplicate2}>
                  <div className={styles.duplicate3}>
                    <div className={styles.duplicate4}>
                      <div className={styles.amirUddin1}>Amir Uddin</div>
                      <div className={styles.uxDesigner1}>{`UX Designer `}</div>
                    </div>
                    <img
                      className={styles.duplicateChild}
                      alt=""
                      src="/line-3.svg"
                    />
                  </div>
                </div>
                <div
                  className={styles.weWillAlso1}
                >{`We will also facilitate the business marketing of these products with our SEO experts so that they become a ready to use website & help sell product from company. We will also facilitate the business marketing of these products with our SEO experts so  facilitate the business marketing of these products `}</div>
                <div className={styles.duplicate5}>
                  <div className={styles.employiaParent}>
                    <i className={styles.employia1}>Employia</i>
                    <img
                      className={styles.vectorIcon1}
                      loading="lazy"
                      alt=""
                      src="/vector-4.svg"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <ContentItems rectangle57="/rectangle-57-2@2x.png" />
        <ContentItems rectangle57="/rectangle-57-3@2x.png" />
        <div className={styles.rectangleGroup}>
          <div className={styles.rectangleDiv} />
          <img
            className={styles.frameChild2}
            alt=""
            src="/rectangle-56@2x.png"
          />
          <img
            className={styles.frameChild3}
            loading="lazy"
            alt=""
            src="/rectangle-56@2x.png"
          />
          <div className={styles.duplicate6}>
            <div className={styles.duplicate7}>
              <div className={styles.duplicate8}>
                <div className={styles.amirUddin2}>Amir Uddin</div>
              </div>
              <div className={styles.duplicate9}>
                <div className={styles.uxDesigner2}>{`UX Designer `}</div>
              </div>
              <div className={styles.duplicate10}>
                <img
                  className={styles.duplicateItem}
                  alt=""
                  src="/line-3.svg"
                />
              </div>
              <div className={styles.duplicate11}>
                <div
                  className={styles.weWillAlso2}
                >{`We will also facilitate the business marketing of these products with our SEO experts so that they become a ready to use website & help sell product from company. We will also facilitate the business marketing of these products with our SEO experts so  facilitate the business marketing of these products `}</div>
              </div>
              <div className={styles.duplicate12}>
                <div className={styles.employiaGroup}>
                  <i className={styles.employia2}>Employia</i>
                  <img
                    className={styles.vectorIcon2}
                    alt=""
                    src="/vector-4.svg"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className={styles.contentItems2}>
          <div className={styles.rectangleContainer}>
            <div className={styles.frameChild4} />
            <img
              className={styles.frameChild5}
              alt=""
              src="/rectangle-56@2x.png"
            />
            <img
              className={styles.frameChild6}
              loading="lazy"
              alt=""
              src="/rectangle-57-1@2x.png"
            />
            <div className={styles.frameWrapper}>
              <div className={styles.frameParent}>
                <div className={styles.amirUddinWrapper}>
                  <div className={styles.amirUddin3}>Amir Uddin</div>
                </div>
                <div className={styles.uxDesignerWrapper}>
                  <div className={styles.uxDesigner3}>{`UX Designer `}</div>
                </div>
                <div className={styles.vectorWrapper}>
                  <img className={styles.lineIcon} alt="" src="/line-3.svg" />
                </div>
                <div className={styles.duplicate13}>
                  <div
                    className={styles.weWillAlso3}
                  >{`We will also facilitate the business marketing of these products with our SEO experts so that they become a ready to use website & help sell product from company. We will also facilitate the business marketing of these products with our SEO experts so  facilitate the business marketing of these products `}</div>
                </div>
                <div className={styles.duplicate14}>
                  <div className={styles.employiaContainer}>
                    <i className={styles.employia3}>Employia</i>
                    <img
                      className={styles.vectorIcon3}
                      alt=""
                      src="/vector-4.svg"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className={styles.contentItems3}>
          <div className={styles.groupDiv}>
            <div className={styles.frameChild7} />
            <img
              className={styles.frameChild8}
              alt=""
              src="/rectangle-56@2x.png"
            />
            <img
              className={styles.frameChild9}
              loading="lazy"
              alt=""
              src="/rectangle-57-2@2x.png"
            />
            <div className={styles.frameContainer}>
              <div className={styles.frameGroup}>
                <div className={styles.amirUddinContainer}>
                  <div className={styles.amirUddin4}>Amir Uddin</div>
                </div>
                <div className={styles.uxDesignerContainer}>
                  <div className={styles.uxDesigner4}>{`UX Designer `}</div>
                </div>
                <div className={styles.vectorContainer}>
                  <img
                    className={styles.frameChild10}
                    alt=""
                    src="/line-3.svg"
                  />
                </div>
                <div className={styles.weWillAlsoFacilitateTheBuWrapper}>
                  <div
                    className={styles.weWillAlso4}
                  >{`We will also facilitate the business marketing of these products with our SEO experts so that they become a ready to use website & help sell product from company. We will also facilitate the business marketing of these products with our SEO experts so  facilitate the business marketing of these products `}</div>
                </div>
                <div className={styles.frameDiv}>
                  <div className={styles.employiaParent1}>
                    <i className={styles.employia4}>Employia</i>
                    <img
                      className={styles.vectorIcon4}
                      alt=""
                      src="/vector-4.svg"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className={styles.rectangleParent1}>
          <div className={styles.frameChild11} />
          <img
            className={styles.frameChild12}
            alt=""
            src="/rectangle-56@2x.png"
          />
          <img
            className={styles.frameChild13}
            loading="lazy"
            alt=""
            src="/rectangle-57-3@2x.png"
          />
          <div className={styles.frameWrapper1}>
            <div className={styles.frameParent1}>
              <div className={styles.amirUddinFrame}>
                <div className={styles.amirUddin5}>Amir Uddin</div>
              </div>
              <div className={styles.uxDesignerFrame}>
                <div className={styles.uxDesigner5}>{`UX Designer `}</div>
              </div>
              <div className={styles.vectorFrame}>
                <img className={styles.frameChild14} alt="" src="/line-3.svg" />
              </div>
              <div className={styles.weWillAlsoFacilitateTheBuContainer}>
                <div
                  className={styles.weWillAlso5}
                >{`We will also facilitate the business marketing of these products with our SEO experts so that they become a ready to use website & help sell product from company. We will also facilitate the business marketing of these products with our SEO experts so  facilitate the business marketing of these products `}</div>
              </div>
              <div className={styles.frameWrapper2}>
                <div className={styles.employiaParent2}>
                  <i className={styles.employia5}>Employia</i>
                  <img
                    className={styles.vectorIcon5}
                    alt=""
                    src="/vector-4.svg"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Component;
