import styles from "./content-items.module.css";

const ContentItems = ({ rectangle57 }) => {
  return (
    <div className={styles.contentItems}>
      <div className={styles.rectangleParent}>
        <div className={styles.frameChild} />
        <img className={styles.frameItem} alt="" src="/rectangle-56@2x.png" />
        <img
          className={styles.frameInner}
          loading="lazy"
          alt=""
          src={rectangle57}
        />
        <div className={styles.frameWrapper}>
          <div className={styles.frameParent}>
            <div className={styles.frameContainer}>
              <div className={styles.frameGroup}>
                <div className={styles.frameDiv}>
                  <div className={styles.duplicateParent}>
                    <div className={styles.duplicate}>
                      <div className={styles.amirUddin}>Amir Uddin</div>
                      <div className={styles.uxDesigner}>{`UX Designer `}</div>
                    </div>
                    <img className={styles.lineIcon} alt="" src="/line-3.svg" />
                  </div>
                </div>
                <div
                  className={styles.weWillAlso}
                >{`We will also facilitate the business marketing of these products with our SEO experts so that they become a ready to use website & help sell product from company. We will also facilitate the business marketing of these products with our SEO experts so  facilitate the business marketing of these products `}</div>
              </div>
            </div>
            <div className={styles.employiaParent}>
              <i className={styles.employia}>Employia</i>
              <img className={styles.vectorIcon} alt="" src="/vector-4.svg" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ContentItems;
