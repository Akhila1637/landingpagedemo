import { useCallback } from "react";
import styles from "./footer.module.css";

const Footer = () => {
  const onProductContainer1Click = useCallback(() => {
    // Please sync "Partership pages" to the project
  }, []);

  const onProductContainer2Click = useCallback(() => {
    // Please sync "Pricing" to the project
  }, []);

  const onProductContainerClick = useCallback(() => {
    // Please sync "About us" to the project
  }, []);

  const onProductContainer12Click = useCallback(() => {
    // Please sync "Contect us" to the project
  }, []);

  return (
    <section className={styles.footer}>
      <div className={styles.valueTransformer}>
        <div className={styles.valueTransformerChild} />
        <img className={styles.maskGroupIcon} loading="lazy" alt="" />
      </div>
      <div className={styles.rectangleParent}>
        <footer className={styles.frameChild} />
        <div className={styles.menuColumns}>
          <div className={styles.columnOne}>
            <div className={styles.productMenu}>
              <div className={styles.productName}>
                <div className={styles.productHeader}>
                  <div className={styles.productColumn}>
                    <b className={styles.product}>Product</b>
                    <div className={styles.productParent}>
                      <div className={styles.product1}>
                        <div className={styles.product2}>Features</div>
                      </div>
                      <div
                        className={styles.product3}
                        onClick={onProductContainer1Click}
                      >
                        <div className={styles.product4}>Integration</div>
                      </div>
                      <div
                        className={styles.product5}
                        onClick={onProductContainer2Click}
                      >
                        <div className={styles.product6}>Pricing</div>
                      </div>
                    </div>
                  </div>
                  <div className={styles.resourcesMenu}>
                    <b className={styles.resources}>Resources</b>
                    <div className={styles.resourceLinks}>
                      <div className={styles.product7}>
                        <div className={styles.product8}>Content Hub</div>
                      </div>
                      <div className={styles.product9}>
                        <div className={styles.product10}>
                          API documentation
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className={styles.madeWithContainer}>
                <span>{`Made with `}</span>
                <span className={styles.span}>❤</span>
                <span>️ from india for the World 🇮🇳</span>
              </div>
            </div>
            <div className={styles.companyColumn}>
              <div className={styles.companyColumn1}>
                <b className={styles.company}>Company</b>
              </div>
              <div className={styles.companyItems}>
                <div className={styles.companyLinks}>
                  <div
                    className={styles.product11}
                    onClick={onProductContainerClick}
                  >
                    <div className={styles.product12}>About us</div>
                  </div>
                  <div
                    className={styles.product13}
                    onClick={onProductContainer12Click}
                  >
                    <div className={styles.product14}>Contact us</div>
                  </div>
                </div>
                <div className={styles.product15}>
                  <div className={styles.product16}>Partnerships</div>
                </div>
              </div>
              <div className={styles.carrers}>Carrers</div>
            </div>
          </div>
          <div className={styles.copyright}>
            <div className={styles.copyright2024}>
              Copyright © 2024 employia.ltd All rights reserved
            </div>
          </div>
        </div>
        <div className={styles.legalColumn}>
          <div className={styles.legalColumn1}>
            <div className={styles.legalTitle}>
              <div className={styles.legalName}>
                <b className={styles.legal}>Legal</b>
              </div>
              <div className={styles.productGroup}>
                <div className={styles.product17}>
                  <div className={styles.product18}>{`Terms & Conditions`}</div>
                </div>
                <div className={styles.product19}>
                  <div className={styles.product20}>{`Privacy Policy `}</div>
                </div>
                <div className={styles.product21}>
                  <div className={styles.product22}>Refund policy</div>
                </div>
              </div>
            </div>
          </div>
          <div className={styles.logoFooter}>
            <div className={styles.footerLogoContainer}>
              <img
                className={styles.logoIcon}
                loading="lazy"
                alt=""
                src="/vector-18.svg"
              />
            </div>
            <i className={styles.employia}>Employia</i>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Footer;
