import styles from "./edge-link.module.css";

const EdgeLink = () => {
  return (
    <section className={styles.edgeLink}>
      <img className={styles.edgeLinkChild} alt="" src="/rectangle-25.svg" />
      <div className={styles.imageContainer}>
        <img
          className={styles.subtreePathIcon}
          loading="lazy"
          alt=""
          src="/rectangle-45@2x.png"
        />
      </div>
      <div className={styles.loremIpsumDolorSitAmetParent}>
        <h1 className={styles.loremIpsumDolorContainer}>
          <p className={styles.loremIpsumDolor}>Lorem ipsum dolor sit amet</p>
        </h1>
        <div className={styles.description}>
          <div className={styles.loremIpsumDolor1}>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam quis
            justo ac justo mattis volutpat non sit amet dolor. Sed gravida,
            sapien sit amet tristique tempor, ante dolor suscipit nisi, non
            pulvinar felis felis vel mi. Proin vitae sapien id justo faucibus
            placerat. Pellentesque habitant morbi tristique senectus et netus et
            malesuada fames ac turpis egestas. Integer sed vestibulum ipsum.
            Vestibulum ante ipsum primis in faucibus orci luctus et ultrices
            posuere cubilia curae; Sed ac nisi ultricies, cursus odio non,
            sagittis urna. Integer consequat ipsum vitae justo laoreet, nec
            molestie nisl molestie.
          </div>
        </div>
      </div>
    </section>
  );
};

export default EdgeLink;
