import styles from "./group-component1.module.css";

const GroupComponent1 = () => {
  return (
    <section className={styles.frameParent}>
      <div className={styles.testimonalsThatIllustrateParent}>
        <h1
          className={styles.testimonalsThatIllustrate}
        >{`Testimonals that illustrate `}</h1>
        <div className={styles.macbookPro169Parent}>
          <div className={styles.macbookPro169} />
          <div className={styles.macbookPro1691} />
          <div className={styles.macbookPro1692} />
          <img
            className={styles.subtreeIcon}
            loading="lazy"
            alt=""
            src="/rectangle-54@2x.png"
          />
        </div>
      </div>
      <div className={styles.ourServiceImpactWrapper}>
        <h1 className={styles.ourServiceImpact}>Our service impact</h1>
      </div>
    </section>
  );
};

export default GroupComponent1;
