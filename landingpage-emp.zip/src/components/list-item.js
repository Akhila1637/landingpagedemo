import { Button } from "@mui/material";
import styles from "./list-item.module.css";

const ListItem = () => {
  return (
    <div className={styles.listItem}>
      <div className={styles.macbookPro169} />
      <div className={styles.macbookPro1691} />
      <div className={styles.macbookPro1692}>
        <Button
          className={styles.macbookPro169Child}
          disableElevation={true}
          variant="contained"
          sx={{
            textTransform: "none",
            color: "#000",
            fontSize: "25.2",
            background: "#d9d9d9",
            borderRadius: "0px 0px 0px 0px",
            "&:hover": { background: "#d9d9d9" },
            width: 253.1,
            height: 83,
          }}
        >
          Get started
        </Button>
      </div>
      <div className={styles.rectangleParent}>
        <div className={styles.frameChild} />
        <div className={styles.frameParent}>
          <div className={styles.vectorParent}>
            <img className={styles.frameItem} alt="" src="/vector-2.svg" />
            <img
              className={styles.siblingsSubtreeIcon}
              loading="lazy"
              alt=""
              src="/vector-2.svg"
            />
          </div>
          <div className={styles.leafCluster}>
            <img
              className={styles.branchingSubtreeIcon}
              alt=""
              src="/branching-subtree.svg"
            />
            <div className={styles.parentSubtree}>
              <img
                className={styles.descendantSubtreeIcon}
                alt=""
                src="/branching-subtree.svg"
              />
              <i className={styles.employia}>Employia</i>
              <img
                className={styles.edgeSubtreeIcon}
                alt=""
                src="/edge-subtree.svg"
              />
            </div>
          </div>
          <div className={styles.treelet} />
          <div className={styles.nestedTree}>
            <div className={styles.nestedTreeChild} />
            <Button
              className={styles.ogIn}
              disableElevation={true}
              variant="contained"
              sx={{
                textTransform: "none",
                color: "#fff",
                fontSize: "32.1",
                background:
                  "linear-gradient(257.57deg, #170039, #803cb6 81.62%, #57297c)",
                borderRadius: "0px 0px 0px 0px",
                "&:hover": {
                  background:
                    "linear-gradient(257.57deg, #170039, #803cb6 81.62%, #57297c)",
                },
                width: 184.9,
                height: 92,
              }}
            >
              Log in
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ListItem;
