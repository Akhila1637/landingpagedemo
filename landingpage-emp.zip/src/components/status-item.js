import { useMemo } from "react";
import { Button } from "@mui/material";
import styles from "./status-item.module.css";

const StatusItem = ({
  iNFOSYS,
  propBackgroundColor,
  propBorder,
  propBackgroundColor1,
  propBorder1,
}) => {
  const statusItemStyle = useMemo(() => {
    return {
      backgroundColor: propBackgroundColor,
      border: propBorder,
    };
  }, [propBackgroundColor, propBorder]);

  const rectangleDivStyle = useMemo(() => {
    return {
      backgroundColor: propBackgroundColor1,
      border: propBorder1,
    };
  }, [propBackgroundColor1, propBorder1]);

  return (
    <div className={styles.statusItem} style={statusItemStyle}>
      <div className={styles.statusItemChild} style={rectangleDivStyle} />
      <div className={styles.frameParent}>
        <div className={styles.statusIconsParent}>
          <div className={styles.statusIcons} />
          <div className={styles.frameChild} />
          <div className={styles.frameItem} />
          <div className={styles.roundResultParent}>
            <div className={styles.roundResult}>
              <div className={styles.infosys}>{iNFOSYS}</div>
            </div>
            <div className={styles.finalRound}>Final Round</div>
          </div>
        </div>
        <div className={styles.moreButton}>
          <Button
            className={styles.moreButtonChild}
            disableElevation={true}
            variant="contained"
            sx={{
              textTransform: "none",
              color: "#fff",
              fontSize: "12.3",
              background: "#000",
              borderRadius: "0px 0px 0px 0px",
              "&:hover": { background: "#000" },
              width: 137.8,
              height: 29.8,
            }}
          >
            View more
          </Button>
        </div>
      </div>
    </div>
  );
};

export default StatusItem;
