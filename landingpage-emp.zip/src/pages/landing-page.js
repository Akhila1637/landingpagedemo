import EdgeLink from "../components/edge-link";
import ListItem from "../components/list-item";
import GroupComponent1 from "../components/group-component1";
import SearchBar from "../components/search-bar";
import Component from "../components/component";
import FrameComponent1 from "../components/frame-component1";
import FrameComponent from "../components/frame-component";
import Footer from "../components/footer";
import styles from "./landing-page.module.css";

const LandingPage = () => {
  return (
    <div className={styles.landingPage}>
      <EdgeLink />
      <section className={styles.listItemParent}>
        <ListItem />
        <div className={styles.worldsFirstCandidateContainer}>
          <p className={styles.worldsFirstCandidate}>World's First Candidate</p>
          <p className={styles.trackingSoftware}>Tracking Software.</p>
        </div>
        <div className={styles.checkWithOur}>
          Check with our CTS whether you should HIRE or NOT!
        </div>
        <div className={styles.wrapperSpacer}>
          <img className={styles.spacerIcon} alt="" src="/spacer@2x.png" />
        </div>
      </section>
      <GroupComponent1 />
      <section className={styles.ancestorChain} />
      <div className={styles.landingPageChild} />
      <section className={styles.searchBarParent}>
        <SearchBar />
        <div className={styles.recursion}>
          <div className={styles.recursionChild} />
          <h1 className={styles.loremIpsumDolorContainer}>
            <p className={styles.loremIpsumDolor}>Lorem ipsum dolor sit amet</p>
          </h1>
          <div className={styles.loremIpsumDolorContainer1}>
            <p className={styles.loremIpsumDolor1}>
              Lorem ipsum dolor sit amet Lorem ipsum
            </p>
            <p className={styles.blankLine}>&nbsp;</p>
            <p className={styles.blankLine1}>&nbsp;</p>
          </div>
          <div className={styles.loremIpsumDolorSitAmetCoWrapper}>
            <div className={styles.loremIpsumDolor2}>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam
              quis justo ac justo mattis volutpat non sit amet dolor. Sed
              gravida, sapien sit amet tristique tempor, ante dolor suscipit
              nisi, non pulvinar felis felis vel mi. Proin vitae sapien id justo
              faucibus placerat. Pellentesque habitant morbi tristique senectus
              et netus et malesuada fames ac turpis egestas. Integer sed
              vestibulum ipsum. Vestibulum ante ipsum primis in faucibus orci
              luctus et ultrices posuere cubilia curae; Sed ac nisi ultricies,
              cursus odio non, sagittis urna. Integer consequat ipsum vitae
              justo laoreet, nec molestie nisl molestie.
            </div>
          </div>
        </div>
      </section>
      <Component />
      <section className={styles.edgeChainWrapper}>
        <div className={styles.edgeChain}>
          <FrameComponent1 />
          <FrameComponent />
        </div>
      </section>
      <Footer />
    </div>
  );
};

export default LandingPage;
